/** Automatically generated file. DO NOT MODIFY */
package com.umeng_social_sdk_res_lib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}